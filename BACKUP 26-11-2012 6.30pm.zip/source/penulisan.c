/* NIM/Nama 	: 13511087 / Dinah Kamilah Ulfa 										  
   Nama file 	: penulisan.c
   Topik 		: 
   Tanggal 		: 
   Deskripsi 	: */
   
#include <stdio.h>
#include <stdlib.h>
#include "boolean.h"
#include "mesinKata_v1.h"
#include "penulisan.h"

boolean identitas (Kata snd)
//memeriksa apakah nama pengirim dan penerima telah terdaftar pada sistem sebagai pelanggan
//snd:sender:pengirim
//rcv:receiver:penerima
{
	//KAMUS
	boolean found;
	//ALGORITMA
	while (!found)
	{
		STARTKATA();
		if IsKataSama(snd, CKata)
			found = true;
		else
			ADVKATA();
	}
	return found;
}
boolean teschar (Kata psn);
//mengecek apakah seluruh tanda baca dan karakter khusus telah terdefinisi di kamus

void translate();
//mengubah dan menyimpan pesan ke file di folder outbox

void hitungkata (int kpj, int kpn, int tbc);
//Menghitung jumlah kata
//kpj:kata panjang
//kpn:kata pendek
//tbc:tanda baca

void hitungharga();
//menghitung total harga telegram

void statistik();
// menghitung total jumlah pesan yang dikirim, total harganya, serta jumlah rata-rata kata per pesan







