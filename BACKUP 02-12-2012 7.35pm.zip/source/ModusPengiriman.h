#ifndef M_PENGIRIMAN
#define M_PENGIRIMAN

#include "penulisan.h"
#include "mesinKata_v1.h"

void TransmitPesan (void);

TipeNamaFile GetFirstFileOutbox(void);

int HitJumlahPesanOutbox (void);

void MakeNameFileSending (TipeNamaFile NamaFileLama, TipeNamaFile * NamaFileBaru);

void MakeNameFileInbox (TipeNamaFile NamaFileSending, TipeNamaFile * NamaFileInbox);

void StatistikPengiriman (void);

void UpdateStatistikPengiriman (void);

int PanjangNamaFile (char * nama);

int GetPriorityFile(TipeNamaFile NamaFile);

void SendingAfter30seconds(void);

TipeNamaFile ConvertToNamaFile(Kata NamaFile);

void UpdateStatistikPsn (Kata NamaPenerima);

#endif
