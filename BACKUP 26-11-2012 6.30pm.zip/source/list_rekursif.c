#include "list_rekursif.h"
#include <stdio.h>
#include <stdlib.h>

address LAlokasi (linfotype X)
{
	// Kamus
	address P;
	
	// Algoritma
	P = (address) malloc (sizeof (ElmtList));
	if (P != Nil)
	{
		Info(P) = X;
		Next(P) = Nil;
	}
	return P;
}

void LDealokasi (address *P)
{
	free (*P);
}

linfotype FirstElmt (List L)
{
	return Info(L);
}

List Tail (List L)
{
	return Next(L);
} 

List Konsb (linfotype e, List L)
{
	// Kamus
	address P;
	
	// Algoritma
	P = LAlokasi (e);
	if (P == Nil)
		return L;
	else
	{
		Next(P) = L;
		return P;
	}
}

List Konse (List L, linfotype e)
{
	// Kamus
	address P;
	
	// Algoritma
	if (IsListEmpty (L))
		return LAlokasi(e);
	else
	{
		if (Next(L) == Nil)
			Next(L) = LAlokasi (e);
		else
			P = Konse (Tail (L), e);
		return L;
	}
}

boolean IsListEmpty (List L)
{
	return (L == Nil);
}

List Copy (List L)
{
	if (IsListEmpty (L))
		return Nil;
	else
		return (Konsb (FirstElmt (L), Tail (L)));
}

List Concat (List L1, List L2)
{
	if (IsListEmpty (L1))
		return (Copy (L2));
	else
		return (Konsb (FirstElmt (L1), Concat (Tail (L1), L2)));
}

void PrintList (List L)
{
	if (!IsListEmpty (L))
	{
		printf ("%d ", FirstElmt (L));
		PrintList (Tail(L));
	}
}

int NBElmtList (List L)
{
	if (IsListEmpty (L))
		return 0;
	else
		return (NBElmtList (Tail (L)) + 1);
}

boolean Search (List L, linfotype X)
{
	if (IsListEmpty (L))
		return false;
	else
	{
		if (FirstElmt (L) == X)
			return true;
		else
			return (Search (Tail (L), X));
	}
}
