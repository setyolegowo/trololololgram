/*
 * ######################### TUGAS BESAR ###############################
 * 
 * Nama/NIM :
 * 	-> Arief Rahman/13511020
 *  -> Azalea Fisitania/13511028
 *  -> Dinah Kamilah Ulfa/13511087
 *  -> Rifki Afina Putri/13511066
 *  -> Setyo Legowo/13511071
 * 
 * Kelas : 3
 * 
 * Mata Kuliah : IF2030/Algoritma dan Struktur Data
 * 
 * Tahun Ajaran : 2012/2013
 * 
 * Nama File : main_program.c
 * 
 * Deskripsi : 
*/

/* ****************************************************************** */
/*                              HEADER                                */
/* ****************************************************************** */
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <time.h>
#include "boolean.h"
#include "list.h"
#include "p_queue.h"
#include "mesinkar.h"
#include "interface.h"
#include "konfigurasi.h"
#include "modusKonfigurasi.h" // modus konfigurasi


/* ######################### KAMUS GLOBAL ########################### */
extern char * Pita_karakter;
extern char CC;
boolean EndKata;

List statistik_inboks;
List statistik_outboks;
List statistik_sending;
unsigned int tDaftarHarga[5];
struct {
	unsigned int kode;
	Kata nama;
} tDaftarKar[30];
int nKarReg;
List tDaftarPelanggan;
Queue tQueue;

/* ############# DEFINISI DAN SPESIFIKASI SUB-PROGRAM ############### */
void CheckFileFolder(char * name, char dOf);
// 
boolean __inisialisasi();
//


/* ######################## PROGRAM UTAMA ########################### */
int main() {
	// KAMUS LOKAL
	boolean IsInitSukses;
	char pilih1;
	unsigned int pilih2, pilihSubMenu, jeda;
	// i_menu digunakan untuk kondisi menu mana yang dipilih
	
	// ALGORITMA
	printf("loading...");
	IsInitSukses = __inisialisasi();
	if(IsInitSukses == true) {
		// Tampilkan daftar menu {BELUM ADA}
		// { Keluaran berupa interger yang digunakan untuk memilih menu
		//   dibawah sehingga nilai integer tersebut terdefinisi }
		do {
			Header();
			jeda = 1; delay(jeda);
			Menu();
			scanf("%c", &pilih1); //pilihan: A, B, C, atau D
			switch(pilih1) {
				case 'A':
					do {
						ModusA();
						scanf("%d",&pilih2);
						switch(pilih2)
						{
							case 1:
								A1();
								printf("\nPesan berhasil direkam_\n");
								delay(jeda);
							break;
							case 2:
							break;
							case 3:
							break;
						}
					} while ((pilih2 != 8) && (pilih2 != 9));
					break;
				case 'B':
					do {
						ModusB();
						scanf("%d",&pilih2);
						switch(pilih2) 
						{
							case 1:
								A1();
								printf("\nPesan berhasil direkam_\n");
								delay(jeda);
							break;
							case 2:
							break;
							case 3:
							break;
                        }
					} while ((pilih2 != 8) && (pilih2 != 9));
					break;
					case 'C':
						ModusC();
						scanf("%d",&pilih2);
					break;
					case 'D':
						Header();
						ModusD();
						scanf("%d",&pilih2);
						switch(pilih2)
						{
							case 1: show_daftarHarga(); break;
							case 2: show_listItemKamus(); break;
						}
						printf("Masukkan 8 untuk kembali ke menu > ");
						scanf("%d",&pilih2);
					break;
			}
		} while (pilih2 != 9);
	} else {
		// Tampilkan informasi kenapa inisialisasi gagal
	}
	return 0;
}

/* #################### REALISASI SUB-PROGRAM ####################### */
void CheckFileFolder(char * name, char dOf)
{
	struct stat st;
	FILE *fp;
	
	if(stat(name,&st) != 0)
	{
		printf(" %s is not found. Create it...",name);
		if(dOf == 'd') {
			mkdir(name,S_IRWXU);
		} else if (dOf == 'f') {
			fp = fopen(name,"w");
			fprintf(fp,"%c",MARK);
			fclose(fp);
		}
		printf("\n");
	} // else printf(" %s found.\n",name);
}

boolean __inisialisasi()
{
	/* *** KAMUS LOKAL *** */
	boolean CurrentBoolean;
	
	/* ***  ALGORITMA  *** */
	CurrentBoolean = false;
	CreateList(&statistik_inboks,3);
	CreateList(&statistik_outboks,4);
	CreateList(&statistik_sending,3);
	CreateList(&tDaftarPelanggan,1);
	// Cek apakah direktori dan file yang digunakan program ini ada atau
	// tidak. Lalu, jika tidak ada dibuat direktori dan file defaultnya.
	CheckFileFolder("Inbox",'d');
	CheckFileFolder("Inbox/statistik.pesan.txt",'f');
	CheckFileFolder("Outbox",'d');
	CheckFileFolder("Outbox/statistik.pelanggan.txt",'f');
	CheckFileFolder("Pengaturan",'d');
	CheckFileFolder("Pengaturan/konfigurasi.txt",'f');
	CheckFileFolder("Pengaturan/karakterSpesial.txt",'f');
	CheckFileFolder("Pengaturan/listHarga.txt",'f');
	CheckFileFolder("Pengaturan/listPelanggan.txt",'f');
	CheckFileFolder("Pengaturan/listInbox.txt",'f');
	CheckFileFolder("Pengaturan/listOutbox.txt",'f');
	CheckFileFolder("Pengaturan/listSending.txt",'f');
	CheckFileFolder("Sending",'d');
	CheckFileFolder("Sending/statistik.date.txt",'f');
	CheckFileFolder("Sending/currentQueue.txt",'f');
	
	// Mengambil informasi konfigurasi dari file
	// -> Mengambil informasi daftar harga
	DaftarHarga();
	// -> Mengambil list item kamus
	ListItem();
	// -> List pelanggan
	BacaListFromFile(&tDaftarPelanggan,"Pengaturan/listPelanggan.txt");
	
	// Mengambil informasi statistik dari file
	// -> Baca statistik pelanggan
	BacaListFromFile(&statistik_outboks,"Outbox/statistik.pelanggan.txt");
	// -> Baca statistik date
	BacaListFromFile(&statistik_sending,"Sending/statistik.date.txt");
	// -> Baca statistik pesan
	BacaListFromFile(&statistik_inboks,"Inbox/statistik.pesan.txt");

	// Mengurutkan kembali queue
	BacaPQueue(&tQueue);
	
	CurrentBoolean = true;
	return CurrentBoolean;
}
