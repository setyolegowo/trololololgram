/* NIM/Nama 	: 13511087 / Dinah Kamilah Ulfa 										  
   Nama file 	: penulisan.h
   Topik 		: 
   Tanggal 		: 
   Deskripsi 	: */

#ifndef penulisan_h
#define penulisan_h

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include "boolean.h"
#include "endecode.h"
#include "mesinKata_v1.h"
#include "list.h"
#include "modusKonfigurasi.h"
#include "konfigurasi.h"

#define size 100
time_t timer;
char str[size];
const char *format;
struct tm *timeptr;
typedef struct {
	char TabKata[size];
	int Length;
} TipeNamaFile;

boolean identitas (Kata snd);
//memeriksa apakah nama pengirim dan penerima telah terdaftar pada sistem sebagai pelanggan
//snd:sender:pengirim
//rcv:receiver:penerima

boolean teschar (Kata psn);
//mengecek apakah seluruh tanda baca dan karakter khusus telah terdefinisi di kamus

void readJustKata(Kata *k);
//membaca hanya kata pertama yang ditulis
//dengan kata lain karakter-karakter sebelum karakter enter, spasi, dan karakter selain alphanumeric

void read (Kata *k);
//membaca nama pengirim, penerima, dan pesan

void MakeNameFile(Kata Nama, TipeNamaFile *NamaFile);
//Membuat nama file sesuai waktu

void translate(char Prio, Kata snd, Kata rcv, Kata psn);
//mengubah dan menyimpan pesan ke file di folder outbox

// ************************** Ikut nambahin ya din :) *********************************************
void Kirim();

void HitungHarga(Kata snd, Kata rcv);
//menghitung total harga telegram
void HitungHargaTerakhir(void);
// Menampilkan kembali harga terakhir pesan yang dikirim
void StatistikTulis(void);
// menghitung total jumlah pesan yang dikirim, total harganya, serta jumlah rata-rata kata per pesan

#endif
