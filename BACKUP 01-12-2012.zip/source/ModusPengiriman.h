#ifndef M_PENGIRIMAN
#define M_PENGIRIMAN

#include "penulisan.h"
#include "mesinKata_v1.h"

void TransmitPesan (void);

Kata ConvertNamaFile(TipeNamaFile NamaFile);

TipeNamaFile GetFirstFileOutbox(void);

int HitJumlahPesanOutbox (void);

void MakeNameFileSending (TipeNamaFile NamaFileLama, TipeNamaFile * NamaFileBaru);

void MakeNameFileInbox (TipeNamaFile NamaFileSending, TipeNamaFile * NamaFileInbox);

int PanjangNamaFile (char * nama);

int GetPriorityFile(TipeNamaFile NamaFile);

void SendingAfter30seconds(void);

#endif
