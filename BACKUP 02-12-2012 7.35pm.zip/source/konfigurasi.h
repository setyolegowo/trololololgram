#ifndef KONFIGURASI_H
#define KONFIGURASI_H

#include "list.h"
#include "p_queue.h"

void DaftarHarga(void);

void ListItem(void);

void TulisListItem(void);

void BacaListFromFile(List * L, char * pitaKarakter);

void BacaListForFile(List L, char * pitaKarakter);

void BacaPQueue(Queue * PQ);

void TulisPitakar(void);

#endif //KONFIGURASI_H
