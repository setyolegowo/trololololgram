#include <dirent.h>
#include "p_queue.h"
#include "mesinkar.h"
#include "mesinKata_v1.h"
#include "list.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include "pohon_biner.h"
#include "endecode.h"
#include <unistd.h>
#include "ModusPengiriman.h"

extern char CC;

extern Queue tQueue;
//extern List statistik_sending;
extern char *Pita_karakter;
extern Kata CKata;
//extern boolean EndKata;

extern time_t curtime, timeafter;

void TransmitPesan (void)
{
	// Kamus
	BinTree P;
	TipeNamaFile NamaFileBaru, NamaFileLama;
	
	// Algoritma
	Pita_karakter = "Pengaturan/pitakar.txt";
	START();
	BuildTree (&P);
	CLOSEBACA();
	printf("  %d ",HitJumlahPesanOutbox());
	while (HitJumlahPesanOutbox() != 0)
	{
		NamaFileLama = GetFirstFileOutbox();
		Pita_karakter = NamaFileLama.TabKata;
		START();
		MakeNameFileSending(NamaFileLama, &NamaFileBaru);
		Pita_karakter = NamaFileBaru.TabKata;
		STARTW ();
		EncodeMorse (P, CC);
		ADV();
		while (CC != MARK) {
			WRITE(' ');
			EncodeMorse (P, CC);
			ADV();
		}
		WRITE('#');
		CLOSETULIS();
		CLOSEBACA();
		Add(&tQueue,ConvertNamaFile(NamaFileBaru),GetPriorityFile(NamaFileBaru));
		remove (NamaFileLama.TabKata);
	}
}
Kata ConvertNamaFile(TipeNamaFile NamaFile)
{
	// Kamus
	Kata TKata;
	int i;
	
	// Algoritma
	for(i=0; i <= NamaFile.Length; i++)
		TKata.TabKata[i] = NamaFile.TabKata[i];
	TKata.Length = NamaFile.Length;
	return TKata;
}

TipeNamaFile GetFirstFileOutbox(void)
{
	// Kamus
	DIR * dir;
	struct dirent *direntry;
	TipeNamaFile CFile;
	boolean SudahiAja;
	
	// Algoritma
	SudahiAja = false;
	dir = opendir("Outbox");
	while (((direntry = readdir(dir)) != NULL) && !SudahiAja) 
	{
		sprintf(CFile.TabKata, "Outbox/%s", direntry->d_name);
		if(CFile.TabKata [7] != '.') {
			CFile.Length = PanjangNamaFile(CFile.TabKata);
			SudahiAja = true;
		}
	}
	return CFile;
}
TipeNamaFile GetFirstFileSending(void)
{
	// Kamus
	DIR * dir;
	struct dirent *direntry;
	TipeNamaFile CFile;
	boolean SudahiAja;
	
	// Algoritma
	SudahiAja = false;
	dir = opendir("Sending");
	while (((direntry = readdir(dir)) != NULL) && !SudahiAja) 
	{
		sprintf(CFile.TabKata, "Sending/%s", direntry->d_name);
		if(CFile.TabKata [8] != '.') {
			CFile.Length = PanjangNamaFile(CFile.TabKata);
			SudahiAja = true;
		}
	}
	return CFile;
}
int HitJumlahPesanOutbox (void)
/* I.S : List pelanggan dan kamus pada modus pengaturan telah terdefinisi.
   F.S : Menghitung jumlah pesan pada folder outbox */
{
	// Kamus Lokal
	int jumlah;
	DIR *dir;
	struct dirent *direntry;
	struct stat st;
	char ifile[100];
	
	// Algoritma
	dir = opendir("Outbox");
	jumlah = 0;
	while ((direntry = readdir(dir)) != NULL) {
		snprintf(ifile,100,"Outbox/%s",direntry->d_name);
		if((stat(ifile,&st) == 0) && (ifile[7] != '.')) {
			jumlah++;
		}
	}
	return jumlah;
}

int PanjangNamaFile (char * nama)
{
	// Kamus Lokal
	int i = 0;
	
	// ALgoritma
	while(nama[i] != '\0')
		i++;
	return i;
}
void MakeNameFileSending (TipeNamaFile NamaFileLama, TipeNamaFile * NamaFileBaru)
{
	int i;
	
	(*NamaFileBaru).TabKata[0] = 'S'; (*NamaFileBaru).TabKata[1] = 'e'; 
	(*NamaFileBaru).TabKata[2] = 'n'; (*NamaFileBaru).TabKata[3] = 'd';
	(*NamaFileBaru).TabKata[4] = 'i'; (*NamaFileBaru).TabKata[5] = 'n';
	(*NamaFileBaru).TabKata[6] = 'g'; (*NamaFileBaru).TabKata[7] = '/';
	for(i=7; i <= NamaFileLama.Length; i++)
		(*NamaFileBaru).TabKata[i+1] = NamaFileLama.TabKata[i];
	(*NamaFileBaru).Length = i;
}

void MakeNameFileInbox (TipeNamaFile NamaFileSending, TipeNamaFile * NamaFileInbox)
{
	int i;
	
	(*NamaFileInbox).TabKata[0] = 'I'; (*NamaFileInbox).TabKata[1] = 'n'; 
	(*NamaFileInbox).TabKata[2] = 'n'; (*NamaFileInbox).TabKata[3] = 'o';
	(*NamaFileInbox).TabKata[4] = 'x'; (*NamaFileInbox).TabKata[5] = '/';
	for(i=6; i <= NamaFileSending.Length; i++)
		(*NamaFileInbox).TabKata[i] = NamaFileSending.TabKata[i+2];
	(*NamaFileInbox).Length = i;
}

int GetPriorityFile(TipeNamaFile NamaFile)
{	
	Pita_karakter = NamaFile.TabKata;
	STARTKATA();
	ADVKATA();
	ADVKATA();
	CLOSEBACA();
	return ((int) (CKata.TabKata[1] - '0'));
}

void SendingAfter30seconds(void)
{
	/* KAMUS LOKAL */
	TipeNamaFile FileSending, FileInbox;
	BinTree P;
	qinfotype X;
	int Pr;
	
	/*  ALGORITMA  */
	curtime = time(NULL);
	Pita_karakter = "Pengaturan/pitakar.txt";
	START();
	BuildTree (&P);
	CLOSEBACA();
	BacaPQueue(&tQueue);
	while ((difftime(curtime,timeafter) >= 30) && (!IsEmpty (tQueue))) {
		FileSending = GetFirstFileSending();
		Pita_karakter = FileSending.TabKata;
		STARTKATA();
		MakeNameFileInbox(FileSending,&FileInbox);
		Pita_karakter = FileInbox.TabKata;
		STARTW ();
		WRITE(DecodeMorse(P));
		ADV();
		while (CC != MARK) {
			WRITE(DecodeMorse (P));
			ADVKATA();
		}
		WRITE('#');
		CLOSETULIS();
		CLOSEBACA();
		Del(&tQueue,&X,&Pr);
		remove (FileSending.TabKata);
		curtime = time(NULL);
		timeafter+=30;
	}
}
