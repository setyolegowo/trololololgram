#include "pohon_biner.h"
#include "mesinkar.h"
#include "mesinKata_v1.h"
#include "boolean.h"

extern char CC;
extern char *Pita_karakter;
extern struct 
{
	unsigned int kode;
	Kata nama;
} tDaftarKar[30];
extern int nKarReg;
extern Kata CKata;

// { *** Encoding dan Decoding *** }
void Encode (BinTree P, char X);
// { I.S. P terdefinisi. X pasti ada di P }
// { F.S. Kode morse dari X ditampilkan }

char Decode (BinTree P, char* C);
// { I.S. P terdefinisi. X pasti ada di P }
// { F.S. Karakter dari kode morse X ditampilkan }

void DecodeTelegram (Kata NamaFile);
// { I.S. Nama file terdefinisi }
// { F.S. File di overwrite menjadi file asli (yang dapat dibaca manusia) }

void EncodeTelegram (Kata NamaFile);
// { I.S. Nama file terdefinisi }
// { F.S. File di overwrite menjadi file telegram }

int SearchKar (char CC);
// { Mengembalikan indeks karakter tanda baca di kamus berdasarkan karakter}
// { Mengembalikan -1 jika tidak ada }

int MemberKar (Kata CKata);
// { Mengembalikan indeks karakter tanda baca di kamus berdasarkan kata }
// { Mengembalikan -1 jika tidak ada }