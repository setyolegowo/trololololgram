#include <dirent.h>
#include "p_queue.h"
#include "mesinkar.h"
#include "mesinKata_v1.h"
#include "list.h"
#include <stdio.h>
#include <stdlib.h>
#include "pohon_biner.h"
#include "endecode.h"

extern Queue tQueue;
extern List statistik_sending;
extern char *Pita_karakter;
extern Kata CKata;
extern boolean EndKata;

void TransmitPesan (void)
{
	// Kamus
	qinfotype X;
	BinTree P;
	char CC;
	int Prio;
	DIR *dir;
	
	// Algoritma
	Pita_karakter = "pitakar.txt";
	START ();
	BuildTree (&P);
	Pita_karakter = HEAD(tQueue);
	STARTW ();
	Pita_karakter = HEAD(tQueue);
	START ();
	while (CC != MARK)
		EncodeMorse (P, CC);
	CLOSETULIS ();
	// Tunggu 30 detik
	Del (&tQueue, &X, &Prio);
	// Hapus File Outbox
}

void SimpanListOutbox (void)
// I.S : List pelanggan dan kamus pada modus pengaturan telah terdefinisi.
// F.S : Menyimpan list pesan-pesan yang siap untuk dikirim di outbox ke list temporary
{
	// Kamus
	int i;
	DIR *dir;
	struct dirent *direntry;
	Kata CFile;
	int Prio;
	List L;
	
	// Algoritma
	CreateList (&(*L));
	dir = opendir("Outbox");
	direntry = readdir(dir);
	direntry = readdir(dir);
	i = 0;
	while ((direntry = readdir(dir)) != NULL) 
	{
		sprintf(CFile.TabKata, "Outbox/%s", direntry->d_name);
		CFile.Length = StrLength (CFile.TabKata);
		Pita_karakter = CFile.Tabkata;
		STARTKATA ();
		ADVKATA ();
		ADVKATA ();
		Prio = CKata.Tabkata[1];
		Add (&tQueue, CFile, Prio);
		i++;
	}
}

int StrLength (char *C)
{
	// Kamus
	int i = 0;
	
	// Algoritma
	while (*C[] != '\0')
		i++;
	return i;
}

