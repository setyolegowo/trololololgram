/*	Nama/NIM	: Setyo Legowo/13511071
	Nama File	: modus_konfigurasi.h
*/

#ifndef MODUS_KONFIGURASI_H
#define MODUS_KONFIGURASI_H

void show_daftarHarga(void);

void show_listItemKamus(void);

void add_listItemKamus(void);

void del_listItemKamus(void);

void show_listPelanggan(void);

void add_listPelanggan(void);

void del_listPelanggan(void);

#endif