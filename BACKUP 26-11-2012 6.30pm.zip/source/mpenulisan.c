#include <math.h>
#include <stdio.h>
#include <stdlib.h>
int main()
{
	/* Kamus */
	FILE *f;
	int NMax;
	NMax = 50;
	typedef struct {
					char TabKata[NMax + 1];
					unsigned int Length;
					} Kata;	
	Kata yang, psn, rcv, snd;
	int retval, i, n;
	/* Algoritma */
	i = 0;
	printf("Nama pengirim: "); 
	while (snd.TabKata[i] != '\n')
	{
		i++;
		scanf("%c", &snd.TabKata[i]);
	}
	for(n = 1; n <= i; n++)
		printf("%c", snd.TabKata[n]);
	snd.Length = i-1;
	printf("%d", snd.Length);
	getchar();
	return 0;
}
	
	
	
	
	