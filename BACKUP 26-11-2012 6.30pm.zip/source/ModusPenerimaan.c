/* MODUS PENERIMAAN */

#include "boolean.h"
#include "mesinKata_v1.h"
#include "ModusPenerimaan.h"
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>

extern char * Pita_karakter;
extern Kata CKata;
extern boolean EndKata;

void TampilListPesan (void)
/* I.S : List pelanggan dan kamus pada modus pengaturan telah terdefinisi.
   F.S : Menampilkan list pesan-pesan yang telah terkirim pada folder inbox. */
{
	// Kamus Lokal
	int i;
	DIR *dir;
	struct dirent *direntry;
	char ifile[100];
	
	// Algoritma
	dir = opendir("D:/Data Kiki/Tugas/Alstrukdat/TUBES/bin/Inbox"); //Ini direktorinya disesuain ajaaa :D
	direntry = readdir(dir);
	direntry = readdir(dir);
	i = 0;
	while ((direntry = readdir(dir)) != NULL) {
		sprintf(ifile, "D:/Data Kiki/Tugas/Alstrukdat/TUBES/bin/Inbox/%s", direntry->d_name);
		printf(ifile);
		printf("\n");
		i++;
	}
}   
   
void AlfabetToSimbol (Kata CKata)
/* Mengubah representasi alfabet dari tanda baca, karakter khusus, dan enter menjadi simbol agar
   lebih mudah dibaca oleh pengguna. */
{
	// Kamus Lokal
	Kata KataTITIK, KataKOMA, KataTITIKDUA, KataENTER;
	sprintf(KataTITIK.TabKata, " TITIK");
	sprintf(KataKOMA.TabKata, " KOMA");
	sprintf(KataTITIKDUA.TabKata, " TitikDua");
	sprintf(KataENTER.TabKata, " ENTER");
	KataTITIK.Length = 5;
	KataKOMA.Length = 4;
	KataTITIKDUA.Length = 8;
	KataENTER.Length = 5;
	
	// Algoritma
	if (IsKataSama(CKata, KataTITIK)) {
		printf(".");
	}
	else if (IsKataSama(CKata, KataKOMA)) {
		printf(",");
	}
	else if (IsKataSama(CKata, KataTITIKDUA)) {
		printf(":");
	}
	else if (IsKataSama(CKata, KataENTER)) {
		printf("\n");
	}
	else {  	// CKata selain kata yang menunjukkan tanda baca
		printf(" ");
		CetakKataToLayar(CKata);
	}
}

void BacaPesan (int id)
/* I.S : List pelanggan dan kamus pada modus pengaturan telah terdefinisi.
   F.S : Menampilkan pesan berdasarkan masukan id pesan dari pengguna. */
{
	// Kamus Lokal
	int i;
	DIR *dir;
	struct dirent *direntry;
	char ifile[100];
	
	// Algoritma
	dir = opendir("D:/Data Kiki/Tugas/Alstrukdat/TUBES/bin/Inbox"); //Ini direktorinya disesuain ajaaa :D
	for (i=0;i<=id+1;i++) {
		direntry = readdir(dir);
	}
	sprintf(ifile, "D:/Data Kiki/Tugas/Alstrukdat/TUBES/bin/Inbox/%s", direntry->d_name); //Ini juga disesuain ajaaa :D
	Pita_karakter = ifile;
	STARTKATA();
	while (!EndKata) {
		AlfabetToSimbol(CKata);
		ADVKATA();
	}
	CLOSEBACA();
	printf("\n\n");
}
   
void HapusPesan (int id)
/* I.S : List pelanggan dan kamus  pada modus pengaturan telah terdefinisi.
   F.S : Menghapus pesan berdasarkan masukan id pesan dari pengguna. Kika id terdefinisi maka pesan
   akan dihapus dari folder "inbox" dan tidak muncul lagi pada list pesan. */
{
	// Kamus Lokal
	int i;
	DIR *dir;
	struct dirent *direntry;
	char ifile[100];
	
	// Algoritma
	dir = opendir("D:/Data Kiki/Tugas/Alstrukdat/TUBES/bin/Inbox"); //Ini direktorinya disesuain ajaaa :D
	for (i=0;i<=id+1;i++) {
		direntry = readdir(dir);
	}
	sprintf(ifile, "D:/Data Kiki/Tugas/Alstrukdat/TUBES/bin/Inbox/%s", direntry->d_name);
	Pita_karakter = ifile;
	remove(ifile);
	if (remove(ifile) != 0 )
		printf("File %s terhapus dari sistem.\n", ifile);
	else
		printf("Error deleting file.\n");
}

void StatistikPesan(void)
/* I.S : List pelanggan dan kamus pada modus pengaturan telah terdefinisi.
   F.S : Mencetak statistik pembacaan yang telah diterima meliputi nama penerima, jumlah pesan yang
   diterima, dan jumlah pesan yang dibaca. */
{
	// Kamus Lokal
	
	
	// Algoritma
	
}
