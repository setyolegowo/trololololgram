#include <stdlib.h>
#include <stdio.h>
#include "list.h"
#include "p_queue.h"
#include "mesinkar.h"
#include "mesinKata_v1.h"

extern char CC;
extern char * Pita_karakter;
extern unsigned int tDaftarHarga[5];
extern struct {
	unsigned int kode;
	Kata nama;
} tDaftarKar[30];
extern int nKarReg;
extern Kata CKata;
extern List statistik_inboks;
extern List statistik_outboks;
extern List statistik_sending;
extern List tDaftarPelanggan;

void DaftarHarga(void) // Bisa update juga
{
	/* KAMUS LOKAL */
	FILE * dh;
	int i;
	
	/* ALGORITMA */
	//Pita_karakter = (char *) malloc(sizeof("Pengaturan/listHarga.txt"));
	Pita_karakter = "Pengaturan/listHarga.txt";
	START();
	if (CC == MARK) {
		// Membuat konfigurasi
		dh = fopen("Pengaturan/listHarga.txt","w");
		fprintf(dh,"0 0 1 500 2 800 3 200 4 700%c",MARK);
		fclose(dh);
	}
	CLOSEBACA();
	STARTKATA();
	// Mengambil konfigurasi
	while(!EOP()) {
		i = KataToBil(CKata);
		ADVKATA();
		tDaftarHarga[i] = KataToBil(CKata);
		ADVKATA();
	}
	CLOSEBACA();
	//free(Pita_karakter);
}

void ListItem(void)
{
	/* KAMUS LOKAL */
	FILE * li;
	unsigned int k, bil1;
	
	/* ALGORITMA */
	Pita_karakter = "Pengaturan/karakterSpesial.txt";
	START();
	if (CC == MARK) {
		li = fopen("Pengaturan/karakterSpesial.txt","w");
		fprintf(li,"033 TANDASERU 034 KUTIPGANDA 035 HASH 036 DOLLAR 037 PERCENTAGE ");
		fprintf(li,"038 AND 039 APOSTROPHE 040 KURUNGBUKA 041 KURUNGTUTUP 042 ASTERISK ");
		fprintf(li,"043 OPERATORTAMBAH 044 KOMA 045 OPERATORKURANG 046 TITIK 047 MIRINGKANAN ");
		fprintf(li,"058 TITIKDUA 059 TITIKKOMA 060 LEBIHKECILDARI 061 OPERANSAMADENGAN ");
		fprintf(li,"062 LEBIHBESARDARI 063 TANDATANYA 064 AT 094 CHARET 092 MIRINGKIRI ");
		fprintf(li,"126 TILDE%c",MARK);
		fclose(li);
	}
	CLOSEBACA();
	k=0;
	STARTKATA();
	while(!EOP())
	{
		bil1 = (100*KarToBil(CKata.TabKata[1])) + (10*KarToBil(CKata.TabKata[2])) + KarToBil(CKata.TabKata[3]);
		tDaftarKar[k].kode = bil1;
		ADVKATA();
		tDaftarKar[k].nama = CKata;
		k++;
		ADVKATA();
	}
	// EOP() dan k dalam keadaan nextnya
	nKarReg = k - 1;
	CLOSEBACA();
	//free(Pita_karakter);
}
void TulisListItem(void)
{
	/* KAMUS LOKAL */
	int i;
	Kata TKata;
	
	/* ALGORITMA */
	Pita_karakter = "Pengaturan/karakterSpesial.txt";
	i = 0;
	STARTW();
	while (i < nKarReg) {
		// Merubah integer ke 3 integer bentuk karakter
		TKata = BilToKata(tDaftarKar[i].kode, 3);
		CetakKataToFile(TKata);
		WRITE(' ');
		CetakKataToFile(tDaftarKar[i].nama);
		WRITE(' ');
		i++;
	}
	// i == nKarReg
	TKata = BilToKata(tDaftarKar[i].kode, 3);
	CetakKataToFile(TKata);
	WRITE(' ');
	CetakKataToFile(tDaftarKar[i].nama);
	WRITE(MARK);
	CLOSETULIS();
}
void BacaListFromFile(List * L, char * pitaKarakter)
{
	/* KAMUS LOKAL */
	address P;
	unsigned int i;
	boolean IsKosong;
	
	/* ALGORITMA */
	Pita_karakter = pitaKarakter;
	DeleteAll(L);
	START();
	if(!EOP())
		IsKosong = false;
	else
		IsKosong = true;
	CLOSEBACA();
	if(!IsKosong) {
		STARTKATA();
		while(!EOP())
		{
			P = Alokasi(CKata,1);
			ADVKATA();
			for(i=2; i<=NList(*L); i++) {
				Info(P,i) = CKata;
				ADVKATA();
			}
			InsertLast(L,P);
		}
		//Tersisa CKata terakhir
		P = Alokasi(CKata,NList(*L));
		InsertLast(L,P);
		CLOSEBACA();
	}
}
void BacaListForFile(List L, char * pitaKarakter)
{
	/* KAMUS LOKAL */
	address P;
	
	/* ALGORITMA */
	if(!IsListEmpty(L)) {
		P = First(L);
		Pita_karakter = pitaKarakter;
		STARTW();
		while(Next(P) != Nil)
		{
			CetakKataToFile(Info(P,1));
			WRITE(' ');
			P = Next(P);
		}
		// Next(P) == Nil (Elemen terakhir)
		CetakKataToFile(Info(P,1));
		WRITE(MARK);
		CLOSETULIS();
	}
}
void BacaPQueue(Queue * PQ)
{
	/* KAMUS LOKAL */
	Kata K;
	int Pr;
	
	/* ALGORITMA */
	Pita_karakter = "Pengaturan/currentQueue.txt";
	
	STARTKATA();
	while(!EOP())
	{
		Pr = KataToBil(CKata);
		ADVKATA();
		K = CKata;
		ADVKATA();
		Add (PQ, K, Pr);
	}
	CLOSEBACA();
	//free(Pita_karakter);
}
