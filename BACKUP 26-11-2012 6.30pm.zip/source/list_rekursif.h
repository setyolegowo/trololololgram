#ifndef LIST_REC_H
#define LIST_REC_H

#include "boolean.h"

// KAMUS
// { List rekursif direpresentasi dengan pointer } 
#define Nil NULL
typedef char linfotype;
typedef struct tElmtList *address;
typedef struct tElmtList 
{
	linfotype info;
	address next;
} ElmtList;
typedef address List;

// Selektor
#define InfoR(P) (P)->info
#define NextR(P) (P)->next

// { *** Manajemen Memori *** } 
address LAlokasi (linfotype X);
// { Mengirimkan address hasil alokasi sebuah elemen }
// { Jika alokasi berhasil, maka address tidak Nil, dan misalnya menghasilkan P, 
// maka Info(P) = X, Next(P) = Nil } 
// { Jika alokasi gagal, mengirimkan Nil } 
void LDealokasi (address *P);
// { I.S. P terdefinisi } 
// { F.S. P dikembalikan ke sistem } 
// { Melakukan dealokasi/pengembalian address P } 

// { *** Primitif-primitif yang harus direalisasikan *** } 
// { *** Selektor *** } 
linfotype FirstElmt (List L);
// { Mengirimkan elemen pertama sebuah list L yang tidak kosong } 
List Tail (List L);
// { Mengirimkan list L yang tidak kosong tanpa elemen pertamanya }

// { *** Konstruktor *** } 
List Konsb (linfotype e, List L);
// { Mengirimkan list L dengan tambahan e sebagai elemen pertamanya } 
// { e harus dialokasi terlebih dahulu } 
// { Jika alokasi e gagal, mengirimkan L } 
List Konse (List L, linfotype e); 
// { Mengirimkan list L dengan tambahan e sebagai elemen terakhir } 
// { e harus dialokasi terlebih dahulu } 
// { Jika alokasi e gagal, mengirimkan L } 

// { *** Predikat *** } 
boolean IsListEmpty (List L);
// { Mengirimkan true jika list kosong, false jika tidak kosong } 
// { Mungkin yang dikirimkan adalah sebuah list kosong} 

// { *** Operasi Lain *** } 
List Copy (List L);
// { Mengirimkan salinan list L (menjadi list baru) } 
// { Jika ada alokasi gagal, mengirimkan L } 
List Concat (List L1, List L2);
// { Mengirimkan salinan hasil konkatenasi list L1 danL2 (menjadi list baru) } 
// { Jika ada alokasi gagal, menghasilkan Nil } 
void PrintList (List L);
// { I.S. L terdefinisi. } 
// { F.S. Setiap elemen list dicetak. } 
int NBElmtList (List L);
// { Mengirimkan banyaknya elemen list L, Nol jika L kosong } 
boolean Search (List L, linfotype X);
// { Mengirim true jika X adalah anggota list, false jika tidak } 

#endif
