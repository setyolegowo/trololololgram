/*	Nama/NIM	: Setyo Legowo/13511071
	Nama File	: modus_konfigurasi.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "mesinkar.h"
#include "mesinKata_v1.h"
#include "list.h"

extern char CC;
extern char * Pita_karakter;
extern unsigned int tDaftarHarga[5];
extern struct {
	unsigned int kode;
	Kata nama;
} tDaftarKar[30];
extern int nKarReg;
extern Kata CKata;
extern List tDaftarPelanggan;

void show_daftarHarga(void)
{
	/* KAMUS LOKAL*/
	int n, i;
	char pause;
	
	/* ALGORITMA */
	n = 4;
	
	printf("\n");
	for(i = 0; i <= n; i++)
	{
		printf("|| Karakter tipe %d seharga %d\n",i,tDaftarHarga[i]);
	}
}

void show_listItemKamus(void)
{
	/* KAMUS LOKAL */
	int i;
	
	/* ALGORITMA */
	for(i = 1; i <= nKarReg; i++)
	{
		printf("|| Karakter %c ditampilkan dengan %s.\n",(char) tDaftarKar[i].kode,tDaftarKar[i].nama.TabKata);
	}
}

void add_listItemKamus(void)
{
	
}

void del_listItemKamus(void);

void show_listPelanggan(void);

void add_listPelanggan(void);

void del_listPelanggan(void);