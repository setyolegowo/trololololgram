#ifndef KONFIGURASI_H
#define KONFIGURASI_H

void DaftarHarga(void);

void ListItem(void);

void BacaListFromFile(List * L, char * pitaKarakter);

void BacaPQueue(Queue * PQ);

#endif //KONFIGURASI_H
